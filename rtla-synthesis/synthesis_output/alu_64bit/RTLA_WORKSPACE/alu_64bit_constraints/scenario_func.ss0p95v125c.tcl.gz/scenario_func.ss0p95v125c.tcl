################################################################################
#
# Created by rtl write_script on Wed Feb  4 18:25:07 2026
#
################################################################################

################################################################################
#
# Units
# time_unit               : 1e-09
# resistance_unit         : 1000000
# capacitive_load_unit    : 1e-15
# voltage_unit            : 1
# current_unit            : 1e-06
# power_unit              : 1e-12
################################################################################


# -origin user
set_clock_latency -min 0.5 [get_clocks {clk}]
# -origin user
set_clock_latency -max 0.55 [get_clocks {clk}]
# Set latency for io paths.
set_clock_uncertainty 0.2 [get_clocks {clk}]
set_clock_transition 0.2 [get_clocks {clk}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 12
set_input_delay -clock [get_clocks {clk}] 0.5 [get_ports {a[63]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 12
set_input_delay -clock [get_clocks {clk}] 0.5 [get_ports {a[62]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 12
set_input_delay -clock [get_clocks {clk}] 0.5 [get_ports {a[61]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 12
set_input_delay -clock [get_clocks {clk}] 0.5 [get_ports {a[60]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 12
set_input_delay -clock [get_clocks {clk}] 0.5 [get_ports {a[59]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 12
set_input_delay -clock [get_clocks {clk}] 0.5 [get_ports {a[58]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 12
set_input_delay -clock [get_clocks {clk}] 0.5 [get_ports {a[57]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 12
set_input_delay -clock [get_clocks {clk}] 0.5 [get_ports {a[56]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 12
set_input_delay -clock [get_clocks {clk}] 0.5 [get_ports {a[55]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 12
set_input_delay -clock [get_clocks {clk}] 0.5 [get_ports {a[54]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 12
set_input_delay -clock [get_clocks {clk}] 0.5 [get_ports {a[53]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 12
set_input_delay -clock [get_clocks {clk}] 0.5 [get_ports {a[52]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 12
set_input_delay -clock [get_clocks {clk}] 0.5 [get_ports {a[51]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 12
set_input_delay -clock [get_clocks {clk}] 0.5 [get_ports {a[50]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 12
set_input_delay -clock [get_clocks {clk}] 0.5 [get_ports {a[49]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 12
set_input_delay -clock [get_clocks {clk}] 0.5 [get_ports {a[48]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 12
set_input_delay -clock [get_clocks {clk}] 0.5 [get_ports {a[47]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 12
set_input_delay -clock [get_clocks {clk}] 0.5 [get_ports {a[46]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 12
set_input_delay -clock [get_clocks {clk}] 0.5 [get_ports {a[45]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 12
set_input_delay -clock [get_clocks {clk}] 0.5 [get_ports {a[44]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 12
set_input_delay -clock [get_clocks {clk}] 0.5 [get_ports {a[43]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 12
set_input_delay -clock [get_clocks {clk}] 0.5 [get_ports {a[42]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 12
set_input_delay -clock [get_clocks {clk}] 0.5 [get_ports {a[41]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 12
set_input_delay -clock [get_clocks {clk}] 0.5 [get_ports {a[40]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 12
set_input_delay -clock [get_clocks {clk}] 0.5 [get_ports {a[39]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 12
set_input_delay -clock [get_clocks {clk}] 0.5 [get_ports {a[38]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 12
set_input_delay -clock [get_clocks {clk}] 0.5 [get_ports {a[37]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 12
set_input_delay -clock [get_clocks {clk}] 0.5 [get_ports {a[36]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 12
set_input_delay -clock [get_clocks {clk}] 0.5 [get_ports {a[35]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 12
set_input_delay -clock [get_clocks {clk}] 0.5 [get_ports {a[34]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 12
set_input_delay -clock [get_clocks {clk}] 0.5 [get_ports {a[33]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 12
set_input_delay -clock [get_clocks {clk}] 0.5 [get_ports {a[32]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 12
set_input_delay -clock [get_clocks {clk}] 0.5 [get_ports {a[31]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 12
set_input_delay -clock [get_clocks {clk}] 0.5 [get_ports {a[30]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 12
set_input_delay -clock [get_clocks {clk}] 0.5 [get_ports {a[29]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 12
set_input_delay -clock [get_clocks {clk}] 0.5 [get_ports {a[28]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 12
set_input_delay -clock [get_clocks {clk}] 0.5 [get_ports {a[27]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 12
set_input_delay -clock [get_clocks {clk}] 0.5 [get_ports {a[26]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 12
set_input_delay -clock [get_clocks {clk}] 0.5 [get_ports {a[25]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 12
set_input_delay -clock [get_clocks {clk}] 0.5 [get_ports {a[24]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 12
set_input_delay -clock [get_clocks {clk}] 0.5 [get_ports {a[23]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 12
set_input_delay -clock [get_clocks {clk}] 0.5 [get_ports {a[22]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 12
set_input_delay -clock [get_clocks {clk}] 0.5 [get_ports {a[21]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 12
set_input_delay -clock [get_clocks {clk}] 0.5 [get_ports {a[20]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 12
set_input_delay -clock [get_clocks {clk}] 0.5 [get_ports {a[19]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 12
set_input_delay -clock [get_clocks {clk}] 0.5 [get_ports {a[18]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 12
set_input_delay -clock [get_clocks {clk}] 0.5 [get_ports {a[17]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 12
set_input_delay -clock [get_clocks {clk}] 0.5 [get_ports {a[16]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 12
set_input_delay -clock [get_clocks {clk}] 0.5 [get_ports {a[15]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 12
set_input_delay -clock [get_clocks {clk}] 0.5 [get_ports {a[14]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 12
set_input_delay -clock [get_clocks {clk}] 0.5 [get_ports {a[13]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 12
set_input_delay -clock [get_clocks {clk}] 0.5 [get_ports {a[12]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 12
set_input_delay -clock [get_clocks {clk}] 0.5 [get_ports {a[11]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 12
set_input_delay -clock [get_clocks {clk}] 0.5 [get_ports {a[10]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 12
set_input_delay -clock [get_clocks {clk}] 0.5 [get_ports {a[9]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 12
set_input_delay -clock [get_clocks {clk}] 0.5 [get_ports {a[8]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 12
set_input_delay -clock [get_clocks {clk}] 0.5 [get_ports {a[7]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 12
set_input_delay -clock [get_clocks {clk}] 0.5 [get_ports {a[6]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 12
set_input_delay -clock [get_clocks {clk}] 0.5 [get_ports {a[5]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 12
set_input_delay -clock [get_clocks {clk}] 0.5 [get_ports {a[4]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 12
set_input_delay -clock [get_clocks {clk}] 0.5 [get_ports {a[3]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 12
set_input_delay -clock [get_clocks {clk}] 0.5 [get_ports {a[2]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 12
set_input_delay -clock [get_clocks {clk}] 0.5 [get_ports {a[1]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 12
set_input_delay -clock [get_clocks {clk}] 0.5 [get_ports {a[0]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 12
set_input_delay -clock [get_clocks {clk}] 0.5 [get_ports {b[63]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 12
set_input_delay -clock [get_clocks {clk}] 0.5 [get_ports {b[62]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 12
set_input_delay -clock [get_clocks {clk}] 0.5 [get_ports {b[61]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 12
set_input_delay -clock [get_clocks {clk}] 0.5 [get_ports {b[60]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 12
set_input_delay -clock [get_clocks {clk}] 0.5 [get_ports {b[59]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 12
set_input_delay -clock [get_clocks {clk}] 0.5 [get_ports {b[58]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 12
set_input_delay -clock [get_clocks {clk}] 0.5 [get_ports {b[57]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 12
set_input_delay -clock [get_clocks {clk}] 0.5 [get_ports {b[56]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 12
set_input_delay -clock [get_clocks {clk}] 0.5 [get_ports {b[55]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 12
set_input_delay -clock [get_clocks {clk}] 0.5 [get_ports {b[54]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 12
set_input_delay -clock [get_clocks {clk}] 0.5 [get_ports {b[53]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 12
set_input_delay -clock [get_clocks {clk}] 0.5 [get_ports {b[52]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 12
set_input_delay -clock [get_clocks {clk}] 0.5 [get_ports {b[51]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 12
set_input_delay -clock [get_clocks {clk}] 0.5 [get_ports {b[50]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 12
set_input_delay -clock [get_clocks {clk}] 0.5 [get_ports {b[49]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 12
set_input_delay -clock [get_clocks {clk}] 0.5 [get_ports {b[48]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 12
set_input_delay -clock [get_clocks {clk}] 0.5 [get_ports {b[47]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 12
set_input_delay -clock [get_clocks {clk}] 0.5 [get_ports {b[46]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 12
set_input_delay -clock [get_clocks {clk}] 0.5 [get_ports {b[45]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 12
set_input_delay -clock [get_clocks {clk}] 0.5 [get_ports {b[44]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 12
set_input_delay -clock [get_clocks {clk}] 0.5 [get_ports {b[43]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 12
set_input_delay -clock [get_clocks {clk}] 0.5 [get_ports {b[42]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 12
set_input_delay -clock [get_clocks {clk}] 0.5 [get_ports {b[41]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 12
set_input_delay -clock [get_clocks {clk}] 0.5 [get_ports {b[40]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 12
set_input_delay -clock [get_clocks {clk}] 0.5 [get_ports {b[39]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 12
set_input_delay -clock [get_clocks {clk}] 0.5 [get_ports {b[38]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 12
set_input_delay -clock [get_clocks {clk}] 0.5 [get_ports {b[37]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 12
set_input_delay -clock [get_clocks {clk}] 0.5 [get_ports {b[36]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 12
set_input_delay -clock [get_clocks {clk}] 0.5 [get_ports {b[35]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 12
set_input_delay -clock [get_clocks {clk}] 0.5 [get_ports {b[34]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 12
set_input_delay -clock [get_clocks {clk}] 0.5 [get_ports {b[33]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 12
set_input_delay -clock [get_clocks {clk}] 0.5 [get_ports {b[32]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 12
set_input_delay -clock [get_clocks {clk}] 0.5 [get_ports {b[31]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 12
set_input_delay -clock [get_clocks {clk}] 0.5 [get_ports {b[30]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 12
set_input_delay -clock [get_clocks {clk}] 0.5 [get_ports {b[29]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 12
set_input_delay -clock [get_clocks {clk}] 0.5 [get_ports {b[28]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 12
set_input_delay -clock [get_clocks {clk}] 0.5 [get_ports {b[27]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 12
set_input_delay -clock [get_clocks {clk}] 0.5 [get_ports {b[26]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 12
set_input_delay -clock [get_clocks {clk}] 0.5 [get_ports {b[25]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 12
set_input_delay -clock [get_clocks {clk}] 0.5 [get_ports {b[24]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 12
set_input_delay -clock [get_clocks {clk}] 0.5 [get_ports {b[23]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 12
set_input_delay -clock [get_clocks {clk}] 0.5 [get_ports {b[22]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 12
set_input_delay -clock [get_clocks {clk}] 0.5 [get_ports {b[21]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 12
set_input_delay -clock [get_clocks {clk}] 0.5 [get_ports {b[20]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 12
set_input_delay -clock [get_clocks {clk}] 0.5 [get_ports {b[19]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 12
set_input_delay -clock [get_clocks {clk}] 0.5 [get_ports {b[18]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 12
set_input_delay -clock [get_clocks {clk}] 0.5 [get_ports {b[17]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 12
set_input_delay -clock [get_clocks {clk}] 0.5 [get_ports {b[16]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 12
set_input_delay -clock [get_clocks {clk}] 0.5 [get_ports {b[15]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 12
set_input_delay -clock [get_clocks {clk}] 0.5 [get_ports {b[14]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 12
set_input_delay -clock [get_clocks {clk}] 0.5 [get_ports {b[13]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 12
set_input_delay -clock [get_clocks {clk}] 0.5 [get_ports {b[12]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 12
set_input_delay -clock [get_clocks {clk}] 0.5 [get_ports {b[11]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 12
set_input_delay -clock [get_clocks {clk}] 0.5 [get_ports {b[10]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 12
set_input_delay -clock [get_clocks {clk}] 0.5 [get_ports {b[9]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 12
set_input_delay -clock [get_clocks {clk}] 0.5 [get_ports {b[8]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 12
set_input_delay -clock [get_clocks {clk}] 0.5 [get_ports {b[7]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 12
set_input_delay -clock [get_clocks {clk}] 0.5 [get_ports {b[6]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 12
set_input_delay -clock [get_clocks {clk}] 0.5 [get_ports {b[5]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 12
set_input_delay -clock [get_clocks {clk}] 0.5 [get_ports {b[4]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 12
set_input_delay -clock [get_clocks {clk}] 0.5 [get_ports {b[3]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 12
set_input_delay -clock [get_clocks {clk}] 0.5 [get_ports {b[2]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 12
set_input_delay -clock [get_clocks {clk}] 0.5 [get_ports {b[1]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 12
set_input_delay -clock [get_clocks {clk}] 0.5 [get_ports {b[0]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 12
set_input_delay -clock [get_clocks {clk}] 0.5 [get_ports {Oper[2]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 12
set_input_delay -clock [get_clocks {clk}] 0.5 [get_ports {Oper[1]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 12
set_input_delay -clock [get_clocks {clk}] 0.5 [get_ports {Oper[0]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 13
set_output_delay -clock [get_clocks {clk}] 0.6 [get_ports {sum[63]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 13
set_output_delay -clock [get_clocks {clk}] 0.6 [get_ports {sum[62]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 13
set_output_delay -clock [get_clocks {clk}] 0.6 [get_ports {sum[61]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 13
set_output_delay -clock [get_clocks {clk}] 0.6 [get_ports {sum[60]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 13
set_output_delay -clock [get_clocks {clk}] 0.6 [get_ports {sum[59]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 13
set_output_delay -clock [get_clocks {clk}] 0.6 [get_ports {sum[58]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 13
set_output_delay -clock [get_clocks {clk}] 0.6 [get_ports {sum[57]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 13
set_output_delay -clock [get_clocks {clk}] 0.6 [get_ports {sum[56]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 13
set_output_delay -clock [get_clocks {clk}] 0.6 [get_ports {sum[55]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 13
set_output_delay -clock [get_clocks {clk}] 0.6 [get_ports {sum[54]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 13
set_output_delay -clock [get_clocks {clk}] 0.6 [get_ports {sum[53]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 13
set_output_delay -clock [get_clocks {clk}] 0.6 [get_ports {sum[52]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 13
set_output_delay -clock [get_clocks {clk}] 0.6 [get_ports {sum[51]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 13
set_output_delay -clock [get_clocks {clk}] 0.6 [get_ports {sum[50]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 13
set_output_delay -clock [get_clocks {clk}] 0.6 [get_ports {sum[49]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 13
set_output_delay -clock [get_clocks {clk}] 0.6 [get_ports {sum[48]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 13
set_output_delay -clock [get_clocks {clk}] 0.6 [get_ports {sum[47]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 13
set_output_delay -clock [get_clocks {clk}] 0.6 [get_ports {sum[46]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 13
set_output_delay -clock [get_clocks {clk}] 0.6 [get_ports {sum[45]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 13
set_output_delay -clock [get_clocks {clk}] 0.6 [get_ports {sum[44]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 13
set_output_delay -clock [get_clocks {clk}] 0.6 [get_ports {sum[43]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 13
set_output_delay -clock [get_clocks {clk}] 0.6 [get_ports {sum[42]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 13
set_output_delay -clock [get_clocks {clk}] 0.6 [get_ports {sum[41]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 13
set_output_delay -clock [get_clocks {clk}] 0.6 [get_ports {sum[40]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 13
set_output_delay -clock [get_clocks {clk}] 0.6 [get_ports {sum[39]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 13
set_output_delay -clock [get_clocks {clk}] 0.6 [get_ports {sum[38]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 13
set_output_delay -clock [get_clocks {clk}] 0.6 [get_ports {sum[37]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 13
set_output_delay -clock [get_clocks {clk}] 0.6 [get_ports {sum[36]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 13
set_output_delay -clock [get_clocks {clk}] 0.6 [get_ports {sum[35]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 13
set_output_delay -clock [get_clocks {clk}] 0.6 [get_ports {sum[34]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 13
set_output_delay -clock [get_clocks {clk}] 0.6 [get_ports {sum[33]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 13
set_output_delay -clock [get_clocks {clk}] 0.6 [get_ports {sum[32]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 13
set_output_delay -clock [get_clocks {clk}] 0.6 [get_ports {sum[31]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 13
set_output_delay -clock [get_clocks {clk}] 0.6 [get_ports {sum[30]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 13
set_output_delay -clock [get_clocks {clk}] 0.6 [get_ports {sum[29]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 13
set_output_delay -clock [get_clocks {clk}] 0.6 [get_ports {sum[28]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 13
set_output_delay -clock [get_clocks {clk}] 0.6 [get_ports {sum[27]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 13
set_output_delay -clock [get_clocks {clk}] 0.6 [get_ports {sum[26]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 13
set_output_delay -clock [get_clocks {clk}] 0.6 [get_ports {sum[25]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 13
set_output_delay -clock [get_clocks {clk}] 0.6 [get_ports {sum[24]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 13
set_output_delay -clock [get_clocks {clk}] 0.6 [get_ports {sum[23]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 13
set_output_delay -clock [get_clocks {clk}] 0.6 [get_ports {sum[22]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 13
set_output_delay -clock [get_clocks {clk}] 0.6 [get_ports {sum[21]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 13
set_output_delay -clock [get_clocks {clk}] 0.6 [get_ports {sum[20]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 13
set_output_delay -clock [get_clocks {clk}] 0.6 [get_ports {sum[19]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 13
set_output_delay -clock [get_clocks {clk}] 0.6 [get_ports {sum[18]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 13
set_output_delay -clock [get_clocks {clk}] 0.6 [get_ports {sum[17]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 13
set_output_delay -clock [get_clocks {clk}] 0.6 [get_ports {sum[16]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 13
set_output_delay -clock [get_clocks {clk}] 0.6 [get_ports {sum[15]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 13
set_output_delay -clock [get_clocks {clk}] 0.6 [get_ports {sum[14]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 13
set_output_delay -clock [get_clocks {clk}] 0.6 [get_ports {sum[13]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 13
set_output_delay -clock [get_clocks {clk}] 0.6 [get_ports {sum[12]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 13
set_output_delay -clock [get_clocks {clk}] 0.6 [get_ports {sum[11]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 13
set_output_delay -clock [get_clocks {clk}] 0.6 [get_ports {sum[10]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 13
set_output_delay -clock [get_clocks {clk}] 0.6 [get_ports {sum[9]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 13
set_output_delay -clock [get_clocks {clk}] 0.6 [get_ports {sum[8]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 13
set_output_delay -clock [get_clocks {clk}] 0.6 [get_ports {sum[7]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 13
set_output_delay -clock [get_clocks {clk}] 0.6 [get_ports {sum[6]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 13
set_output_delay -clock [get_clocks {clk}] 0.6 [get_ports {sum[5]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 13
set_output_delay -clock [get_clocks {clk}] 0.6 [get_ports {sum[4]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 13
set_output_delay -clock [get_clocks {clk}] 0.6 [get_ports {sum[3]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 13
set_output_delay -clock [get_clocks {clk}] 0.6 [get_ports {sum[2]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 13
set_output_delay -clock [get_clocks {clk}] 0.6 [get_ports {sum[1]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 13
set_output_delay -clock [get_clocks {clk}] 0.6 [get_ports {sum[0]}]
set_max_transition 0.15 [get_clocks {clk}] -clock_path
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/m_func.tcl, \
#   line 22
group_path -name REGOUT -to [get_ports {sum[63] sum[62] sum[61] sum[60] sum[59] \
    sum[58] sum[57] sum[56] sum[55] sum[54] sum[53] sum[52] sum[51] sum[50] \
    sum[49] sum[48] sum[47] sum[46] sum[45] sum[44] sum[43] sum[42] sum[41] \
    sum[40] sum[39] sum[38] sum[37] sum[36] sum[35] sum[34] sum[33] sum[32] \
    sum[31] sum[30] sum[29] sum[28] sum[27] sum[26] sum[25] sum[24] sum[23] \
    sum[22] sum[21] sum[20] sum[19] sum[18] sum[17] sum[16] sum[15] sum[14] \
    sum[13] sum[12] sum[11] sum[10] sum[9] sum[8] sum[7] sum[6] sum[5] sum[4] \
    sum[3] sum[2] sum[1] sum[0]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/m_func.tcl, \
#   line 23
group_path -name REGIN -from [get_ports {a[63] a[62] a[61] a[60] a[59] a[58] \
    a[57] a[56] a[55] a[54] a[53] a[52] a[51] a[50] a[49] a[48] a[47] a[46] \
    a[45] a[44] a[43] a[42] a[41] a[40] a[39] a[38] a[37] a[36] a[35] a[34] \
    a[33] a[32] a[31] a[30] a[29] a[28] a[27] a[26] a[25] a[24] a[23] a[22] \
    a[21] a[20] a[19] a[18] a[17] a[16] a[15] a[14] a[13] a[12] a[11] a[10] \
    a[9] a[8] a[7] a[6] a[5] a[4] a[3] a[2] a[1] a[0] b[63] b[62] b[61] b[60] \
    b[59] b[58] b[57] b[56] b[55] b[54] b[53] b[52] b[51] b[50] b[49] b[48] \
    b[47] b[46] b[45] b[44] b[43] b[42] b[41] b[40] b[39] b[38] b[37] b[36] \
    b[35] b[34] b[33] b[32] b[31] b[30] b[29] b[28] b[27] b[26] b[25] b[24] \
    b[23] b[22] b[21] b[20] b[19] b[18] b[17] b[16] b[15] b[14] b[13] b[12] \
    b[11] b[10] b[9] b[8] b[7] b[6] b[5] b[4] b[3] b[2] b[1] b[0] Oper[2] \
    Oper[1] Oper[0]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit/data/constraints/m_func.tcl, \
#   line 24
group_path -name FEEDTHROUGH -from [get_ports {a[63] a[62] a[61] a[60] a[59] \
    a[58] a[57] a[56] a[55] a[54] a[53] a[52] a[51] a[50] a[49] a[48] a[47] \
    a[46] a[45] a[44] a[43] a[42] a[41] a[40] a[39] a[38] a[37] a[36] a[35] \
    a[34] a[33] a[32] a[31] a[30] a[29] a[28] a[27] a[26] a[25] a[24] a[23] \
    a[22] a[21] a[20] a[19] a[18] a[17] a[16] a[15] a[14] a[13] a[12] a[11] \
    a[10] a[9] a[8] a[7] a[6] a[5] a[4] a[3] a[2] a[1] a[0] b[63] b[62] b[61] \
    b[60] b[59] b[58] b[57] b[56] b[55] b[54] b[53] b[52] b[51] b[50] b[49] \
    b[48] b[47] b[46] b[45] b[44] b[43] b[42] b[41] b[40] b[39] b[38] b[37] \
    b[36] b[35] b[34] b[33] b[32] b[31] b[30] b[29] b[28] b[27] b[26] b[25] \
    b[24] b[23] b[22] b[21] b[20] b[19] b[18] b[17] b[16] b[15] b[14] b[13] \
    b[12] b[11] b[10] b[9] b[8] b[7] b[6] b[5] b[4] b[3] b[2] b[1] b[0] Oper[2] \
    Oper[1] Oper[0]}] -to [get_ports {sum[63] sum[62] sum[61] sum[60] sum[59] \
    sum[58] sum[57] sum[56] sum[55] sum[54] sum[53] sum[52] sum[51] sum[50] \
    sum[49] sum[48] sum[47] sum[46] sum[45] sum[44] sum[43] sum[42] sum[41] \
    sum[40] sum[39] sum[38] sum[37] sum[36] sum[35] sum[34] sum[33] sum[32] \
    sum[31] sum[30] sum[29] sum[28] sum[27] sum[26] sum[25] sum[24] sum[23] \
    sum[22] sum[21] sum[20] sum[19] sum[18] sum[17] sum[16] sum[15] sum[14] \
    sum[13] sum[12] sum[11] sum[10] sum[9] sum[8] sum[7] sum[6] sum[5] sum[4] \
    sum[3] sum[2] sum[1] sum[0]}]

# MD5_SIGNATURE: A650D0C8F852D9D29047906C50166826 
