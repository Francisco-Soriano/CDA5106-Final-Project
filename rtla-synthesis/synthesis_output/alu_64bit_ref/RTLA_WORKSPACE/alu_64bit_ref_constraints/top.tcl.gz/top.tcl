################################################################################
#
# Design name:  alu_64bit_ref
#
# Created by rtl write_script on Wed Feb  4 18:19:16 2026
#
################################################################################

################################################################################
#
# Units
# time_unit               : 1e-09
# resistance_unit         : 1000000
# capacitive_load_unit    : 1e-15
# voltage_unit            : 1
# current_unit            : 1e-06
# power_unit              : 1e-12
################################################################################


set dirName [file dirname [file normalize [info script]]]
set extName "tcl.gz"
set scenarioNames [list func.ss0p95v125c]
set     modeNames [list func]
set   cornerNames [list ss0p95v125c]

foreach scenarioName $scenarioNames \
          modeName   $modeNames \
          cornerName $cornerNames {
  if {$scenarioName == "default"} {
    current_scenario $scenarioName
    source ${dirName}/mode_${modeName}.${extName}
    source ${dirName}/corner_${cornerName}.${extName}
    source ${dirName}/scenario_${scenarioName}.${extName}
    source ${dirName}/design.${extName}
    if {[file exists ${dirName}/${scenarioName}_act.${extName}]} {
        source ${dirName}/${scenarioName}_act.${extName}
    }
  } else {
    create_scenario -name $scenarioName \
      -specific_data {${dirName}/mode_${modeName}.${extName} \
                      ${dirName}/corner_${cornerName}.${extName} \
                      ${dirName}/scenario_${scenarioName}.${extName}} \
      -common_data   ${dirName}/design.${extName}
    if {[file exists ${dirName}/${scenarioName}_act.${extName}]} {
        source ${dirName}/${scenarioName}_act.${extName}
    }
  }
}
# MD5_SIGNATURE: 66EB7C189576DC092387EEB6BA1D8C88 
