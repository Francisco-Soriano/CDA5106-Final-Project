################################################################################
#
# Created by rtl write_script on Wed Feb  4 18:19:16 2026
#
################################################################################

################################################################################
#
# Units
# time_unit               : 1e-09
# resistance_unit         : 1000000
# capacitive_load_unit    : 1e-15
# voltage_unit            : 1
# current_unit            : 1e-06
# power_unit              : 1e-12
################################################################################


# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit_ref/data/constraints/m_func.tcl, \
#   line 15; \
#   /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit_ref/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 8; \
#   /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit_ref/data/constraints/s_func.ss0p95v125c.tcl, \
#   line 9
create_clock -name clk -period 4.99025 -waveform {0 2.49513}
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit_ref/data/constraints/m_func.tcl, \
#   line 22
group_path -name REGOUT -to [get_ports {sum[63] sum[62] sum[61] sum[60] sum[59] \
    sum[58] sum[57] sum[56] sum[55] sum[54] sum[53] sum[52] sum[51] sum[50] \
    sum[49] sum[48] sum[47] sum[46] sum[45] sum[44] sum[43] sum[42] sum[41] \
    sum[40] sum[39] sum[38] sum[37] sum[36] sum[35] sum[34] sum[33] sum[32] \
    sum[31] sum[30] sum[29] sum[28] sum[27] sum[26] sum[25] sum[24] sum[23] \
    sum[22] sum[21] sum[20] sum[19] sum[18] sum[17] sum[16] sum[15] sum[14] \
    sum[13] sum[12] sum[11] sum[10] sum[9] sum[8] sum[7] sum[6] sum[5] sum[4] \
    sum[3] sum[2] sum[1] sum[0]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit_ref/data/constraints/m_func.tcl, \
#   line 23
group_path -name REGIN -from [get_ports {a[63] a[62] a[61] a[60] a[59] a[58] \
    a[57] a[56] a[55] a[54] a[53] a[52] a[51] a[50] a[49] a[48] a[47] a[46] \
    a[45] a[44] a[43] a[42] a[41] a[40] a[39] a[38] a[37] a[36] a[35] a[34] \
    a[33] a[32] a[31] a[30] a[29] a[28] a[27] a[26] a[25] a[24] a[23] a[22] \
    a[21] a[20] a[19] a[18] a[17] a[16] a[15] a[14] a[13] a[12] a[11] a[10] \
    a[9] a[8] a[7] a[6] a[5] a[4] a[3] a[2] a[1] a[0] b[63] b[62] b[61] b[60] \
    b[59] b[58] b[57] b[56] b[55] b[54] b[53] b[52] b[51] b[50] b[49] b[48] \
    b[47] b[46] b[45] b[44] b[43] b[42] b[41] b[40] b[39] b[38] b[37] b[36] \
    b[35] b[34] b[33] b[32] b[31] b[30] b[29] b[28] b[27] b[26] b[25] b[24] \
    b[23] b[22] b[21] b[20] b[19] b[18] b[17] b[16] b[15] b[14] b[13] b[12] \
    b[11] b[10] b[9] b[8] b[7] b[6] b[5] b[4] b[3] b[2] b[1] b[0] Oper[2] \
    Oper[1] Oper[0]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit_ref/data/constraints/m_func.tcl, \
#   line 24
group_path -name FEEDTHROUGH -from [get_ports {a[63] a[62] a[61] a[60] a[59] \
    a[58] a[57] a[56] a[55] a[54] a[53] a[52] a[51] a[50] a[49] a[48] a[47] \
    a[46] a[45] a[44] a[43] a[42] a[41] a[40] a[39] a[38] a[37] a[36] a[35] \
    a[34] a[33] a[32] a[31] a[30] a[29] a[28] a[27] a[26] a[25] a[24] a[23] \
    a[22] a[21] a[20] a[19] a[18] a[17] a[16] a[15] a[14] a[13] a[12] a[11] \
    a[10] a[9] a[8] a[7] a[6] a[5] a[4] a[3] a[2] a[1] a[0] b[63] b[62] b[61] \
    b[60] b[59] b[58] b[57] b[56] b[55] b[54] b[53] b[52] b[51] b[50] b[49] \
    b[48] b[47] b[46] b[45] b[44] b[43] b[42] b[41] b[40] b[39] b[38] b[37] \
    b[36] b[35] b[34] b[33] b[32] b[31] b[30] b[29] b[28] b[27] b[26] b[25] \
    b[24] b[23] b[22] b[21] b[20] b[19] b[18] b[17] b[16] b[15] b[14] b[13] \
    b[12] b[11] b[10] b[9] b[8] b[7] b[6] b[5] b[4] b[3] b[2] b[1] b[0] Oper[2] \
    Oper[1] Oper[0]}] -to [get_ports {sum[63] sum[62] sum[61] sum[60] sum[59] \
    sum[58] sum[57] sum[56] sum[55] sum[54] sum[53] sum[52] sum[51] sum[50] \
    sum[49] sum[48] sum[47] sum[46] sum[45] sum[44] sum[43] sum[42] sum[41] \
    sum[40] sum[39] sum[38] sum[37] sum[36] sum[35] sum[34] sum[33] sum[32] \
    sum[31] sum[30] sum[29] sum[28] sum[27] sum[26] sum[25] sum[24] sum[23] \
    sum[22] sum[21] sum[20] sum[19] sum[18] sum[17] sum[16] sum[15] sum[14] \
    sum[13] sum[12] sum[11] sum[10] sum[9] sum[8] sum[7] sum[6] sum[5] sum[4] \
    sum[3] sum[2] sum[1] sum[0]}]

# SPECIAL inbuilt contraints, controlled using app options:  
group_path -name **in2reg_default** -from [all_inputs] -to [all_registers]
group_path -name **reg2out_default** -from [all_registers] -to [all_outputs]
group_path -name **in2out_default** -from [all_inputs] -to [all_outputs]
# MD5_SIGNATURE: 06F03351AFDFF0523002EB7B4BD5C77F 
