################################################################################
#
# Created by rtl write_script on Wed Feb  4 18:19:16 2026
#
################################################################################

################################################################################
#
# Units
# time_unit               : 1e-09
# resistance_unit         : 1000000
# capacitive_load_unit    : 1e-15
# voltage_unit            : 1
# current_unit            : 1e-06
# power_unit              : 1e-12
################################################################################


set_load -pin_load 5 [get_ports {sum[63]}]
set_load -pin_load 5 [get_ports {sum[62]}]
set_load -pin_load 5 [get_ports {sum[61]}]
set_load -pin_load 5 [get_ports {sum[60]}]
set_load -pin_load 5 [get_ports {sum[59]}]
set_load -pin_load 5 [get_ports {sum[58]}]
set_load -pin_load 5 [get_ports {sum[57]}]
set_load -pin_load 5 [get_ports {sum[56]}]
set_load -pin_load 5 [get_ports {sum[55]}]
set_load -pin_load 5 [get_ports {sum[54]}]
set_load -pin_load 5 [get_ports {sum[53]}]
set_load -pin_load 5 [get_ports {sum[52]}]
set_load -pin_load 5 [get_ports {sum[51]}]
set_load -pin_load 5 [get_ports {sum[50]}]
set_load -pin_load 5 [get_ports {sum[49]}]
set_load -pin_load 5 [get_ports {sum[48]}]
set_load -pin_load 5 [get_ports {sum[47]}]
set_load -pin_load 5 [get_ports {sum[46]}]
set_load -pin_load 5 [get_ports {sum[45]}]
set_load -pin_load 5 [get_ports {sum[44]}]
set_load -pin_load 5 [get_ports {sum[43]}]
set_load -pin_load 5 [get_ports {sum[42]}]
set_load -pin_load 5 [get_ports {sum[41]}]
set_load -pin_load 5 [get_ports {sum[40]}]
set_load -pin_load 5 [get_ports {sum[39]}]
set_load -pin_load 5 [get_ports {sum[38]}]
set_load -pin_load 5 [get_ports {sum[37]}]
set_load -pin_load 5 [get_ports {sum[36]}]
set_load -pin_load 5 [get_ports {sum[35]}]
set_load -pin_load 5 [get_ports {sum[34]}]
set_load -pin_load 5 [get_ports {sum[33]}]
set_load -pin_load 5 [get_ports {sum[32]}]
set_load -pin_load 5 [get_ports {sum[31]}]
set_load -pin_load 5 [get_ports {sum[30]}]
set_load -pin_load 5 [get_ports {sum[29]}]
set_load -pin_load 5 [get_ports {sum[28]}]
set_load -pin_load 5 [get_ports {sum[27]}]
set_load -pin_load 5 [get_ports {sum[26]}]
set_load -pin_load 5 [get_ports {sum[25]}]
set_load -pin_load 5 [get_ports {sum[24]}]
set_load -pin_load 5 [get_ports {sum[23]}]
set_load -pin_load 5 [get_ports {sum[22]}]
set_load -pin_load 5 [get_ports {sum[21]}]
set_load -pin_load 5 [get_ports {sum[20]}]
set_load -pin_load 5 [get_ports {sum[19]}]
set_load -pin_load 5 [get_ports {sum[18]}]
set_load -pin_load 5 [get_ports {sum[17]}]
set_load -pin_load 5 [get_ports {sum[16]}]
set_load -pin_load 5 [get_ports {sum[15]}]
set_load -pin_load 5 [get_ports {sum[14]}]
set_load -pin_load 5 [get_ports {sum[13]}]
set_load -pin_load 5 [get_ports {sum[12]}]
set_load -pin_load 5 [get_ports {sum[11]}]
set_load -pin_load 5 [get_ports {sum[10]}]
set_load -pin_load 5 [get_ports {sum[9]}]
set_load -pin_load 5 [get_ports {sum[8]}]
set_load -pin_load 5 [get_ports {sum[7]}]
set_load -pin_load 5 [get_ports {sum[6]}]
set_load -pin_load 5 [get_ports {sum[5]}]
set_load -pin_load 5 [get_ports {sum[4]}]
set_load -pin_load 5 [get_ports {sum[3]}]
set_load -pin_load 5 [get_ports {sum[2]}]
set_load -pin_load 5 [get_ports {sum[1]}]
set_load -pin_load 5 [get_ports {sum[0]}]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit_ref/data/constraints/c_ss0p95v125c.tcl, \
#   line 10
set_voltage 0.95 -object_list {VDD}
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit_ref/data/constraints/c_ss0p95v125c.tcl, \
#   line 11
set_voltage 0 -object_list {VSS}
# Warning: Libcell power domain derates are skipped!

# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit_ref/data/constraints/c_ss0p95v125c.tcl, \
#   line 13
set_timing_derate -early 0.95 -cell_delay -clock [current_design]
# /home/net/jo045021/sp26/rtl-opt-proj/yosys-internal/rtla-synthesis/synthesis_output/alu_64bit_ref/data/constraints/c_ss0p95v125c.tcl, \
#   line 13
set_timing_derate -early 0.95 -cell_delay -data [current_design]
set_timing_derate -early 0.95 -net_delay -clock 
set_timing_derate -early 0.95 -net_delay -data 
### Populated from ICC2 Corner-Specific POCV Corner Sigma Settings ###
set timing_pocvm_corner_sigma 3 
# MD5_SIGNATURE: D2A130788F5648F3A2A48F2E185751FF 
